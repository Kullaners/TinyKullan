Set sh = CreateObject("WScript.Shell")
fldr = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))
py = fldr & "Python\TinyKullan.py"
sh.Run "cmd /c start pythonw """ & py & """", 0, True
' Emergency keyboard unlock on exit
unlock = fldr & "Python\unlock_keyboard.ps1"
If CreateObject("Scripting.FileSystemObject").FileExists(unlock) Then
    sh.Run "powershell -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & unlock & """", 0, False
End If
