Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
fldr = fso.GetParentFolderName(WScript.ScriptFullName) & "\"

py = fldr & "Python\TinyKullan.py"

If Not fso.FileExists(py) Then
    MsgBox "TinyKullan.py not found at: " & py, vbCritical, "TinyKullan"
    WScript.Quit
End If

' Try full python path first, then fall back to pythonw
pythonExe = ""
pythonPaths = Array( _
    sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Programs\Python\Python312\pythonw.exe", _
    sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Programs\Python\Python311\pythonw.exe", _
    sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Microsoft\WindowsApps\python3.exe", _
    "pythonw", _
    "python" _
)

For Each p In pythonPaths
    If fso.FileExists(p) Then
        pythonExe = p
        Exit For
    End If
Next

' If no specific exe found, try command-line pythonw
If pythonExe = "" Then pythonExe = "pythonw"

cmd = "cmd /c start """" """ & pythonExe & """ """ & py & """"
sh.Run cmd, 0, False
