import os
import sys
import tempfile
import unittest
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "Python"))

import TinyKullan as tiny  # noqa: E402


class MacroFormatTests(unittest.TestCase):
    def test_image_upload_copy_uses_managed_library_and_cache(self):
        source = PROJECT_ROOT / "Saves" / "images" / "taseawe.png"
        self.assertTrue(source.is_file())
        original_library = tiny.IMAGES_PATH
        with tempfile.TemporaryDirectory() as directory:
            tiny.IMAGES_PATH = Path(directory) / "images"
            try:
                destination = tiny._copy_image_to_library(source)
                self.assertTrue(destination.is_file())
                self.assertEqual(destination.name, source.name)
                self.assertEqual(destination.read_bytes(), source.read_bytes())
            finally:
                tiny.IMAGES_PATH = original_library

    def test_compact_round_trip_keeps_scroll_and_key_metadata(self):
        events = [
            {"t": "W", "d": 12, "x": 111, "y": 222, "delta": -120},
            {"t": "WH", "d": 5, "x": 333, "y": 444, "delta": 2},
            {"t": "K", "d": 7, "vk": 163, "scan": 29, "ext": True, "up": True},
        ]
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as handle:
            path = handle.name
        try:
            tiny._write_compact_run(events, path)
            loaded = tiny._read_compact_run(path)
        finally:
            os.unlink(path)

        self.assertEqual((loaded[0]["x"], loaded[0]["y"], loaded[0]["delta"]), (111, 222, -120))
        self.assertEqual((loaded[1]["t"], loaded[1]["x"], loaded[1]["y"]), ("WH", 333, 444))
        self.assertEqual((loaded[2]["scan"], loaded[2]["ext"]), (29, True))

    def test_compact_reader_accepts_legacy_scroll_rows(self):
        with tempfile.NamedTemporaryFile(
            suffix=".txt", mode="w", encoding="utf-8", delete=False
        ) as handle:
            handle.write("# TinyKullan Recording\nSCROLL|12|-120\nSCROLL_H|5|9\n")
            path = handle.name
        try:
            loaded = tiny._read_compact_run(path)
        finally:
            os.unlink(path)

        self.assertEqual(loaded[0], {"t": "W", "d": 12, "x": 0, "y": 0, "delta": -120})
        self.assertEqual(loaded[1], {"t": "WH", "d": 5, "x": 0, "y": 0, "delta": 9})

    def test_csv_reader_skips_bad_rows_and_preserves_named_events(self):
        with tempfile.NamedTemporaryFile(
            suffix=".csv", mode="w", encoding="utf-8", delete=False
        ) as handle:
            handle.write("K,not-a-number,0,0,,0,65,30,0,0,\n")
            handle.write("I,0,0,0,,0,0,0,0,0,target%7Cimage.png\n")
            path = handle.name
        try:
            loaded = tiny._read_csv_macro(path)
        finally:
            os.unlink(path)

        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0]["name"], "target|image.png")
        self.assertEqual(loaded[0]["img"], "target|image.png")

    def test_python_only_events_are_routed_away_from_ahk(self):
        self.assertFalse(tiny._requires_python_playback([{"t": "M", "d": 0, "x": 1, "y": 2}]))
        self.assertTrue(tiny._requires_python_playback([{"t": "I", "d": 0, "name": "button"}]))
        self.assertTrue(tiny._requires_python_playback([{"t": "R", "d": 0, "name": "other"}]))
        self.assertTrue(tiny._requires_python_playback([{"t": "D", "d": 100}]))


class ConfigTests(unittest.TestCase):
    def test_config_round_trip_uses_atomic_replace(self):
        original_path = tiny.INI_PATH
        with tempfile.TemporaryDirectory() as directory:
            tiny.INI_PATH = Path(directory) / "TinyKullan.ini"
            try:
                config = tiny.Config()
                config.key_record = "ctrl+r"
                config.playlist_files = ["a.txt"]
                config.pixel_triggers = [{"x": 1}]
                config.save()

                loaded = tiny.Config()
                loaded.load()
                self.assertEqual(loaded.key_record, "ctrl+r")
                self.assertEqual(loaded.playlist_files, ["a.txt"])
                self.assertEqual(loaded.pixel_triggers, [{"x": 1}])
                self.assertFalse((Path(directory) / "TinyKullan.ini.tmp").exists())
            finally:
                tiny.INI_PATH = original_path


if __name__ == "__main__":
    unittest.main()
