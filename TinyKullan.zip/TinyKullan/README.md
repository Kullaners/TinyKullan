# TinyKullan

TinyKullan is a Windows macro recorder/player with optional autoclicking,
screen-image detection, Discord notifications, playlists, statistics, and
Roblox recovery automation. The configuration also contains OCR/pixel trigger
storage, but those trigger types are not currently wired into the detection
loop.

## Project layout

- `Python/TinyKullan.py` — the Tkinter application, configuration, macro
  formats, playback routing, image detection, dashboard, and settings UI.
- `Python/TinyKullan.ahk` — the low-level AutoHotkey recorder/player used for
  timing-sensitive keyboard and mouse input.
- `TinyKullan.vbs` — launches the Python app without a console window.
- `install.bat` — installs Python dependencies, AutoHotkey v2, and optional
  Tesseract OCR.
- `Saves/` — user configuration, image targets, favorites, logs, and saved
  recordings. These files are runtime data, not source code.
- `tests/test_core.py` — headless regression tests for configuration and macro
  serialization.

## Playback model

Raw mouse/keyboard/wheel events use AutoHotkey for low-latency playback.
Events that AutoHotkey cannot represent—image searches, nested runs, and
explicit delays—are routed through the Python playback engine so they are not
silently discarded.

Saved `.txt` recordings use TinyKullan's compact pipe-delimited format. The
reader remains compatible with older recordings that stored scroll events
without coordinates and key events without scan-code metadata.

## Development checks

From the project directory:

```powershell
python -m py_compile Python\TinyKullan.py tests\test_core.py
python -m unittest discover -s tests -v
```

The application is Windows-specific because it uses Windows input APIs and
AutoHotkey.
