@echo off
title TinyKullan Installer
color 0A

echo.
echo  ================================
echo    TinyKullan - Easy Installer
echo  ================================
echo.

:: Check if Python 3.12 is already installed
python --version 2>nul | findstr "3.12" >nul
if %errorlevel%==0 (
    echo  [OK] Python 3.12 is already installed.
    goto install_packages
)

echo  [1/3] Downloading Python 3.12...
echo.
curl -L --progress-bar -o python-3.12.9-amd64.exe https://www.python.org/ftp/python/3.12.9/python-3.12.9-amd64.exe

if not exist python-3.12.9-amd64.exe (
    echo.
    echo  [ERROR] Download failed. Check your internet connection.
    pause
    exit /b 1
)

echo.
echo  [2/3] Installing Python 3.12 (this takes a moment)...
echo.
python-3.12.9-amd64.exe /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1

if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] Installation failed. Try right-clicking and running as Administrator.
    pause
    exit /b 1
)

del python-3.12.9-amd64.exe
set "PATH=%LOCALAPPDATA%\Programs\Python\Python312\;%LOCALAPPDATA%\Programs\Python\Python312\Scripts\;%PATH%"
echo  [OK] Python 3.12 installed.

:install_packages
echo.
echo  [3/3] Installing dependencies...
echo.
pip install pynput keyboard Pillow requests mss opencv-python numpy discord-webhook pystray customtkinter --quiet --progress-bar on

echo.
echo  ================================
echo    Done! You can now run the
echo    TinyKullan.py script.
echo  ================================
echo.
pause