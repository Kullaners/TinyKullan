@echo off
title TinyKullan - One Click Installer
color 0A
cd /d "%~dp0"

echo.
echo  ==================================
echo    TinyKullan Installer
echo    Everything in one go
echo  ==================================
echo.

:: ── Python 3.12 ───────────────────────────────────
echo  [1/3] Python 3.12...
python --version >nul 2>&1
if %errorlevel% equ 0 (
    echo    Already installed.
) else (
    echo    Downloading...
    powershell -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.9/python-3.12.9-amd64.exe' -OutFile 'python_installer.exe'" >nul 2>&1
    if exist python_installer.exe (
        echo    Installing...
        python_installer.exe /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1
        del python_installer.exe
        echo    Done.
    ) else (
        echo    Download failed - skipping. Install Python manually.
    )
)

:: ── Pip packages ───────────────────────────────────
echo.
echo  [2/3] Python packages...

:: Find pip - try PATH first, then common locations
set PIP_CMD=pip
pip --version >nul 2>&1
if %errorlevel% neq 0 (
    if exist "%LocalAppData%\Programs\Python\Python312\Scripts\pip.exe" set PIP_CMD="%LocalAppData%\Programs\Python\Python312\Scripts\pip.exe"
    if exist "%LocalAppData%\Programs\Python\Python312\Scripts\pip3.exe" set PIP_CMD="%LocalAppData%\Programs\Python\Python312\Scripts\pip3.exe"
    if exist "C:\Python312\Scripts\pip.exe" set PIP_CMD="C:\Python312\Scripts\pip.exe"
)

%PIP_CMD% install pynput keyboard Pillow requests mss opencv-python numpy discord-webhook pystray customtkinter pytesseract --quiet --disable-pip-version-check >nul 2>&1
if %errorlevel% equ 0 (
    echo    Done.
) else (
    echo    Retrying with --user...
    %PIP_CMD% install --user pynput keyboard Pillow requests mss opencv-python numpy discord-webhook pystray customtkinter pytesseract --quiet --disable-pip-version-check >nul 2>&1
    if %errorlevel% equ 0 (
        echo    Done.
    ) else (
        echo    Some packages failed - the app will use fallback mode for missing features.
    )
)

:: ── AutoHotkey v2 ──────────────────────────────────
echo.
echo  [3/3] AutoHotkey v2...

:: Check if AHK v2 is already findable
where AutoHotkey64.exe >nul 2>&1
if %errorlevel% equ 0 goto ahk_ok
if exist "%ProgramFiles%\AutoHotkey\v2\AutoHotkey64.exe" goto ahk_ok
if exist "%ProgramFiles%\AutoHotkey\AutoHotkey.exe" goto ahk_ok
if exist "%LocalAppData%\Programs\AutoHotkey\v2\AutoHotkey64.exe" goto ahk_ok

echo    Downloading portable version...
powershell -Command "Invoke-WebRequest -Uri 'https://www.autohotkey.com/download/ahk-v2.zip' -OutFile 'ahk.zip'" >nul 2>&1
if exist ahk.zip (
    echo    Extracting...
    mkdir "%LocalAppData%\Programs\AutoHotkey\v2" 2>nul
    powershell -Command "Expand-Archive -Force 'ahk.zip' '%LocalAppData%\Programs\AutoHotkey\v2'" >nul 2>&1
    del ahk.zip
    echo    Done.
) else (
    echo    Download failed - install manually from autohotkey.com
)
goto folders

:ahk_ok
echo    Already installed.

:: ── Tesseract OCR ──────────────────────────────────
echo.
echo  [4/4] Tesseract OCR...
if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" (
    echo    Already installed.
) else (
    echo    Downloading Tesseract OCR installer...
    powershell -Command "Invoke-WebRequest -Uri 'https://github.com/UB-Mannheim/tesseract/releases/download/v5.4.0.20240606/tesseract-ocr-w64-setup-5.4.0.20240606.exe' -OutFile 'tesseract_installer.exe'" >nul 2>&1
    if exist tesseract_installer.exe (
        echo    Installing Tesseract silently...
        tesseract_installer.exe /S
        del tesseract_installer.exe
        echo    Done.
    ) else (
        echo    Download failed - skipping. Install Tesseract manually if needed.
    )
)

:folders
:: ── Create folders ───────────────────────────────
mkdir "Saves\runs" 2>nul
mkdir "Saves\images" 2>nul
mkdir "Assets\ScreenShots" 2>nul
mkdir "C:\TinyKullan\Assets\ScreenShots" 2>nul

:: ── Done ───────────────────────────────────────────
echo.
echo  ==================================
echo    Ready. Run TinyKullan.py
echo  ==================================
echo.
timeout /t 3 >nul
exit
